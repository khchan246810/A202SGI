package com.example.profilepagecurrent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity { /*For MainActivity, change it into profilepage. For activity_main.xml,
                                                       change it into activity_profilepage.xml or something**/
    ImageButton simplesetting;
    ImageButton profilepage;
    ImageButton briefcase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        simplesetting = findViewById(R.id.simplesetting);
        profilepage = findViewById(R.id.Profile);
        briefcase= findViewById(R.id.Briefcase);

        profilepage.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent=new Intent(MainActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
        briefcase.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent=new Intent(MainActivity.this,myjobspage.class);
                startActivity(intent);
            }
        });
    }
    public void popUpMenu(View v){
        PopupMenu p=new PopupMenu(MainActivity.this,simplesetting);
        p.getMenuInflater().inflate(R.menu.popup_menu,p.getMenu());
        p.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                int itemId = menuItem.getItemId();
                String itemTitle = menuItem.getTitle().toString();
                if (itemId == R.id.item1) {
                    Intent intent=new Intent(MainActivity.this,edit_profile.class);
                    startActivity(intent);
                }
                return true;
            }
        });
        p.show();

    }
}