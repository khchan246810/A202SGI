package com.example.profilepagecurrent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class job_preference extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_preference);
    }
}