package com.example.profilepagecurrent;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.content.SharedPreferences;
import android.widget.Toast;


public class edit_profile extends AppCompatActivity {
    ImageButton simpleImageButtonHome;
    Button upload;
    EditText age, gender, address, experiences;
    TextView resume;

    ImageButton Profilecamera;
    ImageButton profilepage;
    Button change;
    SharedPreferences Sprefs;


    ImageButton briefcase;


    private static final int FILE_SELECT_CODE = 1;
    private TextView fileNameText;
    public static final String mypreference = "mypref";
    public static final String Age = "ageKey";
    public static final String Gender = "genderKey";
    public static final String Address = "addressKey";
    public static final String Resume = "resumeKey";
    public static final String pastExperiences = "pastExperiencesKey";
    private String prefName = "report";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        age = (EditText) findViewById(R.id.age);
        gender = (EditText) findViewById(R.id.gender);
        address = (EditText) findViewById(R.id.address);
        resume = (TextView) findViewById(R.id.file_name_text);
        experiences=(EditText) findViewById(R.id.pastexperience);
        Button change = findViewById(R.id.change);

        change.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Sprefs = getSharedPreferences(prefName, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = Sprefs.edit();

                if (age.getText().toString().equals("")||gender.getText().toString().equals("")||address.getText().toString().equals("") ||resume.getText().toString().equals("")||experiences.getText().toString().equals("")){

                    Toast.makeText(getApplicationContext(), "Please Fill All the Fields",Toast.LENGTH_SHORT).show();
                }
                else if (!Sprefs.getString("id"+address.getText().toString(),"").toString().equals("")){
                    Toast.makeText(getBaseContext(), "User is already Registered",Toast.LENGTH_SHORT).show();
                }
                else {
                    //---save the values in the EditText view to preferences---
                    editor.putString("Age"+age.getText().toString(),age.getText().toString());
                    editor.putString("Gender"+gender.getText().toString(),gender.getText().toString());
                    editor.putString("Address"+address.getText().toString(),address.getText().toString());
                    editor.putString("Resume"+resume.getText().toString(),resume.getText().toString());
                    editor.putString("Past Experiences"+experiences.getText().toString(),experiences.getText().toString());
                    editor.commit();//---saves the values---
                    Toast.makeText(getBaseContext(), "User Details Registered",Toast.LENGTH_SHORT).show();
                    age.setText("");
                    gender.setText("");
                    address.setText("");
                    resume.setText("");
                    experiences.setText("");
                }
            }
        });


        fileNameText = findViewById(R.id.file_name_text);
        Button selectFileButton = findViewById(R.id.upload);

        selectFileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
            }
        });
        Profilecamera = findViewById(R.id.Profilecamera);
        profilepage = findViewById(R.id.Profile);
        profilepage.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent=new Intent(edit_profile.this,MainActivity.class);
                startActivity(intent);
            }
        });
        briefcase= findViewById(R.id.Briefcase);
        briefcase.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent=new Intent(edit_profile.this,myjobspage.class);
                startActivity(intent);
            }
        });
        simpleImageButtonHome = findViewById(R.id.simpleImageButtonHome);
        simpleImageButtonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(edit_profile.this, MainActivity.class);
                startActivity(intent);
            }
        });
        if (ContextCompat.checkSelfPermission(edit_profile.this, android.Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(edit_profile.this, new String[]{
                    Manifest.permission.CAMERA
            }, 100);
        }
        Profilecamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,100);
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == 100 && resultCode == RESULT_OK) {
            Bitmap originalBitmap = (Bitmap) data.getExtras().get("data");

// Resize and crop image to circular shape
            int diameter = Math.min(originalBitmap.getWidth(), originalBitmap.getHeight());
            Bitmap circularBitmap = Bitmap.createBitmap(diameter, diameter, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(circularBitmap);

            Paint paint = new Paint();
            paint.setAntiAlias(true);
            paint.setColor(Color.WHITE);

            float radius = diameter / 2f;
            canvas.drawCircle(radius, radius, radius, paint);

            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
            canvas.drawBitmap(originalBitmap, 0, 0, paint);

// Assign circular bitmap to profile picture view
            Profilecamera.setImageBitmap(circularBitmap);
        }

        if (requestCode == FILE_SELECT_CODE && resultCode == RESULT_OK) {
            Uri uri = data.getData();
            String fileName = getFileName(uri);
            fileNameText.setText(fileName);
        }
    }
    private void showFileChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(intent, "Select File"), FILE_SELECT_CODE);
    }



    private String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    result = cursor.getString(nameIndex);
                }
            }
        }
        if (result == null) {
            result = uri.getPath();
            int cut = result.lastIndexOf('/');
            if (cut != -1) {
                result = result.substring(cut + 1);
            }
        }
        return result;
    }
}
