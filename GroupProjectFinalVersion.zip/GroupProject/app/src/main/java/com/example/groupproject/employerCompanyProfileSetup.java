package com.example.groupproject;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class employerCompanyProfileSetup extends AppCompatActivity {
    private TextView DateText;
    private EditText Name, businessAddress, natureBusiness, companyContact, registeringPerson;
    private ImageButton date;
    private Button confirm;
    private static final int FILE_SELECT_CODE = 1;
    private TextView fileNameText;
    boolean isAllFieldsChecked = false;
    private DatabaseManager dbManager;
    ImageButton simpleImageButtonHome;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employer_company_profile_setup);
        dbManager = new DatabaseManager(this);
        dbManager.open();
        // Get a reference to the Spinner
        Spinner position = findViewById(R.id.position);

        // Create an array with a default item at the beginning
        String[] educationLevelWithDefault = {"Position of the Registering Person", "President", "Manager", "Deputy President", "General Manager", "Boss"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, educationLevelWithDefault);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        position.setAdapter(adapter);
        fileNameText = findViewById(R.id.file_name_text);
        Button selectFileButton = findViewById(R.id.upload);
        selectFileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
            }
        });
        DateText = findViewById(R.id.incorporation);
        date = findViewById(R.id.calendar);
        Name = findViewById(R.id.Name);
        businessAddress= findViewById(R.id.business);
        natureBusiness = findViewById(R.id.nature);
        companyContact= findViewById(R.id.companyContact);
        registeringPerson= findViewById(R.id.registeringPerson);
        ImageButton simpleImageButtonHome=findViewById(R.id.simpleImageButtonHome);
        simpleImageButtonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(employerCompanyProfileSetup.this, employersJobPostings.class);
                startActivity(intent);
            }
        });


        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDatePicker(); // Open date picker dialog
            }
        });
        Button confirmation = findViewById(R.id.confirm);
        confirmation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // store the returned value of the dedicated function which checks
                // whether the entered data is valid or if any fields are left blank.
                isAllFieldsChecked = CheckAllFields();

                // the boolean variable turns to be true then
                // only the user must be proceed to the activity2
                if (isAllFieldsChecked) {
                    saveDataToDatabase();
                    Intent intent=new Intent(employerCompanyProfileSetup.this, MainActivity.class);
                    //Intent intent=new Intent(employerCompanyProfileSetup.this, employersJobPostings.class);//
                    startActivity(intent);
                }
            }
        });
    }
    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == FILE_SELECT_CODE && resultCode == RESULT_OK) {
            Uri uri = data.getData();
            String fileName = getFileName(uri);
            fileNameText.setText(fileName);
        }
    }*/
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_SELECT_CODE && resultCode == RESULT_OK) {
            Uri uri = data.getData();

            // Check the file size limit (e.g., 5 MB)
            int maxSizeBytes = 5 * 1024 * 1024; // 5 MB
            int fileSizeBytes = getFileSize(uri);

            if (fileSizeBytes > maxSizeBytes) {
                // File size exceeds the limit, show an error message
                Toast.makeText(this, "File size exceeds the limit (5 MB)", Toast.LENGTH_SHORT).show();
            } else {
                String fileName = getFileName(uri);
                fileNameText.setText(fileName);
            }
        }
    }

    // Helper method to get the file size from a Uri
    private int getFileSize(Uri uri) {
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
        int size = 0;
        if (cursor != null && cursor.moveToFirst()) {
            int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
            size = cursor.getInt(sizeIndex);
            cursor.close();
        }
        return size;
    }
    private void showFileChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(intent, "Select File"), FILE_SELECT_CODE);
    }
    private String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    result = cursor.getString(nameIndex);
                }
            }
        }
        if (result == null) {
            result = uri.getPath();
            int cut = result.lastIndexOf('/');
            if (cut != -1) {
                result = result.substring(cut + 1);
            }
        }
        return result;
    }
    private void openDatePicker(){
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {

                //Showing the picked value in the textView
                DateText.setText(String.valueOf(year)+ "."+String.valueOf(month)+ "."+String.valueOf(day));

            }
        }, 2023, 01, 20);

        datePickerDialog.show();
    }
    private boolean CheckAllFields() {
        if (TextUtils.isEmpty(Name.getText().toString())) {
            Toast.makeText(employerCompanyProfileSetup.this, "Fill up the fields. For file, date and dropdown, please select it. For contact, must equal 10 digits", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            Name.setError(null); // Clear the error
        }

        if (TextUtils.isEmpty(businessAddress.getText().toString())) {
            Toast.makeText(employerCompanyProfileSetup.this, "Fill up the fields. For file, date and dropdown, please select it. For contact, must equal 10 digits", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            businessAddress.setError(null); // Clear the error
        }
        if (TextUtils.isEmpty(natureBusiness.getText().toString())) {
            Toast.makeText(employerCompanyProfileSetup.this, "Fill up the fields. For file, date and dropdown, please select it. For contact, must equal 10 digits", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            natureBusiness.setError(null); // Clear the error
        }
        if (TextUtils.isEmpty(companyContact.getText().toString())) {
            Toast.makeText(employerCompanyProfileSetup.this, "Fill up the fields. For file, date and dropdown, please select it. For contact, must equal 10 digits", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            companyContact.setError(null); // Clear the error
        }
        if (companyContact.length() !=10 ) {
            Toast.makeText(employerCompanyProfileSetup.this, "Fill up the fields. For file, date and dropdown, please select it. For contact, must equal 10 digits", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            companyContact.setError(null); // Clear the error
        }
        if (TextUtils.isEmpty(registeringPerson.getText().toString())) {
            Toast.makeText(employerCompanyProfileSetup.this, "Fill up the fields. For file, date and dropdown, please select it. For contact, must equal 10 digits", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            registeringPerson.setError(null); // Clear the error
        }

        if (TextUtils.isEmpty(DateText.getText().toString())) {
            Toast.makeText(employerCompanyProfileSetup.this, "Fill up the fields. For file, date and dropdown, please select it. For contact, must equal 10 digits", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            DateText.setError(null); // Clear the error
        }

        if (TextUtils.isEmpty(fileNameText.getText().toString())) {
            Toast.makeText(employerCompanyProfileSetup.this, "Fill up the fields. For file, date and dropdown, please select it. For contact, must equal 10 digits", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            fileNameText.setError(null); // Clear the error
        }

        Spinner position = findViewById(R.id.position);
        if (position.getSelectedItem().toString().equals("Position of the Registering Person")) {
            // If "Choose Area of Interest" is selected, show an error message on the Spinner
            Toast.makeText(employerCompanyProfileSetup.this, "Fill up the fields. For file, date and dropdown, please select it. For contact, must equal 10 digits", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            // Reset error message
            ((TextView) position.getSelectedView()).setError(null);
        }

        // All fields are checked and valid
        return true;
    }
    private void saveDataToDatabase() {
        String name = Name.getText().toString();
        String business = businessAddress.getText().toString();
        String nature = natureBusiness.getText().toString();
        String contact = companyContact.getText().toString();
        String registering = registeringPerson.getText().toString();
        String date = DateText.getText().toString();
        Spinner positionSpinner = findViewById(R.id.position);
        String position = positionSpinner.getSelectedItem().toString();
        String fileName = fileNameText.getText().toString();
        // Insert data into the database
        long result = dbManager.anotherinsertData(name, business, nature, contact, registering,date,position,fileName);

        if (result != -1) {
            // Data inserted successfully
            showToast("Data inserted successfully");
        } else {
            // Failed to insert data
            showToast("Failed to insert data");
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbManager.close();
    }
}