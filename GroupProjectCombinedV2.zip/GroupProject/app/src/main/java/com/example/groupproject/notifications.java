package com.example.groupproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class notifications extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);
        ImageButton notifications=findViewById(R.id.notification);
        notifications.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent=new Intent(notifications.this, notifications.class);
                startActivity(intent);
            }
        });
        ImageButton home=findViewById(R.id.homeIconButton);
        home.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent=new Intent(notifications.this, homeActivity.class);
                startActivity(intent);
            }
        });
        ImageButton profilepage = findViewById(R.id.profileIconButton);
        /*briefcase= findViewById(R.id.Briefcase);*/
        ImageButton job_icon= findViewById(R.id.jobIconButton);
        job_icon.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent=new Intent(notifications.this,myjobspage.class);
                startActivity(intent);
            }
        });

        profilepage.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent=new Intent(notifications.this,profile_page.class);
                startActivity(intent);
            }
        });
    }
}