package com.example.groupproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

public class profile_page extends AppCompatActivity { /*For MainActivity, change it into profilepage. For activity_main.xml,
                                                       change it into activity_profilepage.xml or something**/
    ImageButton simplesetting;
    ImageButton profilepage;
    ImageButton briefcase;
    private TextView name;
    private TextView Phone;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        simplesetting = findViewById(R.id.simplesetting);
        profilepage = findViewById(R.id.profileIconButton);
        briefcase = findViewById(R.id.jobIconButton);
        name = findViewById(R.id.boxtext1);
        Phone = findViewById(R.id.boxtext2); // Change to "box2" to match your XML
        // Retrieve data from the intent
        // Retrieve data in profile_page
        // Retrieve data in profile_page
        SharedPreferences prefs = getSharedPreferences("UserData", MODE_PRIVATE);
        String username = prefs.getString("USERNAME", "");
        String phone = prefs.getString("PHONE", "");
        // Set the data to the TextViews
        name.setText(username);
        Phone.setText(phone);

        ImageButton home=findViewById(R.id.homeIconButton);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(profile_page.this, homeActivity.class);
                startActivity(intent);
            }
        });
        Button logout=findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(profile_page.this, MainActivity.class);
                startActivity(intent);
            }
        });
        profilepage.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent=new Intent(profile_page.this,profile_page.class);
                startActivity(intent);
            }
        });

        briefcase.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent=new Intent(profile_page.this,myjobspage.class);
                startActivity(intent);
            }
        });
    }
    public void popUpMenu(View v){
        PopupMenu p=new PopupMenu(profile_page.this,simplesetting);
        p.getMenuInflater().inflate(R.menu.popup_menu,p.getMenu());
        p.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                int itemId = menuItem.getItemId();
                String itemTitle = menuItem.getTitle().toString();
                if (itemId == R.id.item1) {
                    Intent intent=new Intent(profile_page.this,edit_profile.class);
                    startActivity(intent);
                }
                return true;
            }
        });
        p.show();

    }
}