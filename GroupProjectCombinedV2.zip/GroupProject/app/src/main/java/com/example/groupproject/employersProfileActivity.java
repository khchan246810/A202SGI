package com.example.groupproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;


public class employersProfileActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.employers_profile);
        Button back=findViewById(R.id.backButton);
        ImageButton jobPage=findViewById(R.id.jobIconButton);
        ImageButton home=findViewById(R.id.homeIconButton);
        ImageButton notifications;

        notifications=findViewById(R.id.notification);
        notifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(employersProfileActivity.this, notifications.class);
                startActivity(intent);
            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(employersProfileActivity.this, homeActivity.class);
                startActivity(intent);
            }
        });
        ImageButton profilepage = findViewById(R.id.profileIconButton);
        profilepage.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent=new Intent(employersProfileActivity.this,profile_page.class);
                startActivity(intent);
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(employersProfileActivity.this,vacancyPosition1.class);
                startActivity(intent);
            }
        });
        jobPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(employersProfileActivity.this,myjobspage.class);
                startActivity(intent);
            }
        });
    }
}
