package com.example.groupproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseManager {
    private static final String DATABASE_NAME = "Hustle";
    private static final int DATABASE_VERSION = 1;

    private static final String SignUp_Table = "SignUp";

    private static final String COLUMN_SignUpID = "ID";
    private static final String COLUMN_SignUpName = "Name";
    private static final String COLUMN_SignUpPhone = "Phone_Number";
    private static final String Column_passwordInput = "Password";

    private static final String EditProfile_Table = "EditProfile";

    private static final String COLUMN_EditID = "ID";
    private static final String COLUMN_EditAge = "Age";
    private static final String COLUMN_EditGender = "Gender";
    private static final String Column_EditAddress = "Address";
    private static final String Column_EditFile = "file";
    private static final String Column_pastExperience = "pastExperience";


    private static final String TABLE_NAME = "Employer_Profile";
    private static final String ANOTHER_TABLE_NAME = "Employer_Company_Setup";

    private static final String COLUMN_AnotherID = "ID";
    private static final String COLUMN_CompanyNAME = "Company_Name";
    private static final String COLUMN_Business = "Business_Address";
    private static final String Column_Nature = "Business_Nature";

    private static final String Company_Contact = "Company_Contact";
    private static final String Registering_Person = "Registering_Person";
    private static final String Company_DATE = "Company_Date";

    private static final String Company_file = "Company_File";

    private static final String Position = "Position";

    private static final String COLUMN_ID = "ID";
    private static final String COLUMN_NAME = "NAME";
    private static final String COLUMN_DATE = "DATE";
    private static final String COLUMN_RESIDENTIAL = "RESIDENTIAL_Address";

    private static final String COLUMN_EDUCATION_LEVEL = "EDUCATION_LEVEL";
    private static final String COLUMN_INTEREST_AREA = "INTEREST_AREA";
    private static final String COLUMN_RESUME_PATH = "RESUME_PATH";

    private static final String CREATE_SignUp_Table = "CREATE TABLE IF NOT EXISTS " + SignUp_Table + " ("
            + COLUMN_SignUpID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_SignUpName + " TEXT,"
            + COLUMN_SignUpPhone + " TEXT,"
            + Column_passwordInput + " TEXT"
            + ")";
    private static final String SignUpEmployer_Table = "SignUpEmployer";

    private static final String COLUMN_SignUpEmployerID = "ID";
    private static final String COLUMN_SignUpEmployerName = "Name";
    private static final String COLUMN_SignUpEmployerPhone = "Phone_Number";
    private static final String Column_passwordEmployerInput = "Password";
    private static final String CreateSignUpEmployers_TABLE = "CREATE TABLE IF NOT EXISTS " + SignUpEmployer_Table + " ("
            + COLUMN_SignUpEmployerID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_SignUpEmployerName + " TEXT,"
            + COLUMN_SignUpEmployerPhone + " TEXT,"
            + Column_passwordEmployerInput + " TEXT"
            + ")";
    private static final String CREATE_Edit_Table = "CREATE TABLE IF NOT EXISTS " + EditProfile_Table + " ("
            + COLUMN_EditID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_EditAge + " TEXT,"
            + COLUMN_EditGender + " TEXT,"
            + Column_EditAddress + " TEXT,"
            + Column_EditFile + " TEXT,"
            + Column_pastExperience + " TEXT"
            + ")";
    private static final String CREATE_TABLE_QUERY = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " ("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_NAME + " TEXT,"
            + COLUMN_DATE + " TEXT,"
            + COLUMN_RESIDENTIAL + " TEXT,"
            + COLUMN_RESUME_PATH + " TEXT,"
            + COLUMN_EDUCATION_LEVEL + " TEXT," // Add this line
            + COLUMN_INTEREST_AREA + " TEXT" // Add this line
            + ")";

    private static final String CREATE_ANOTHER_TABLE_QUERY = "CREATE TABLE IF NOT EXISTS " + ANOTHER_TABLE_NAME + " ("
            + COLUMN_AnotherID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_CompanyNAME + " TEXT,"
            + COLUMN_Business + " TEXT,"
            + Column_Nature + " TEXT,"
            + Company_Contact + " TEXT,"
            + Registering_Person + " TEXT,"
            + Company_DATE + " TEXT,"
            + Company_file + " TEXT,"
            + Position + " TEXT"
            // Add more columns for AnotherTable as needed
            + ")";
    private static final String jobPostingsTable = "jobPostings";

    private static final String COLUMN_JobPostingsID = "ID";
    private static final String COLUMN_JobPostingsName = "Name";
    private static final String COLUMN_JobPostingsNature = "Nature_of_Job";
    private static final String COLUMN_JobPostingsDescription = "Job_Description";

    private static final String COLUMN_JobPostingsLocation = "Location";
    private static final String COLUMN_JobPostingsWage = "Wage";
    private static final String COLUMN_JobPostingsminAge= "Min_Age";
    private static final String COLUMN_JobPostingsmaxAge= "Max_Age";
    private static final String COLUMN_JobPostingsnumVacancy= "Number_of_Vacancy";

    private static final String CreateJobPostings_TABLE = "CREATE TABLE IF NOT EXISTS " + jobPostingsTable + " ("
            + COLUMN_JobPostingsID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_JobPostingsName + " TEXT,"
            + COLUMN_JobPostingsNature + " TEXT,"
            + COLUMN_JobPostingsDescription + " TEXT,"
            + COLUMN_JobPostingsLocation + " TEXT,"
            + COLUMN_JobPostingsWage + " TEXT,"
            + COLUMN_JobPostingsminAge + " TEXT,"
            + COLUMN_JobPostingsmaxAge + " TEXT,"
            + COLUMN_JobPostingsnumVacancy + " TEXT"
            // Add more columns for AnotherTable as needed
            + ")";

    private final Context context;
    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    public DatabaseManager(Context context) {
        this.context = context;
    }

    public DatabaseManager open() throws SQLException {
        dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }
    public long jobPostingsData(String name, String nature,String description,String location,String Wage,String min, String max,String vacancy){
        ContentValues values=new ContentValues();
        values.put(COLUMN_JobPostingsName,name);
        values.put(COLUMN_JobPostingsNature,nature);
        values.put(COLUMN_JobPostingsDescription,description);
        values.put(COLUMN_JobPostingsLocation,location);
        values.put(COLUMN_JobPostingsWage,Wage);
        values.put(COLUMN_JobPostingsminAge,min);
        values.put(COLUMN_JobPostingsmaxAge,max);
        values.put(COLUMN_JobPostingsnumVacancy,vacancy);
        return db.insert(jobPostingsTable, null, values);
    }

    public long EditData(String age, String gender, String address, String file, String pastExperiences){
        ContentValues values = new ContentValues();
        values.put(COLUMN_EditAge, age);
        values.put(COLUMN_EditGender, gender);
        values.put(Column_EditAddress, address);
        values.put(Column_EditFile, file);
        values.put(Column_pastExperience, pastExperiences);
        return db.insert(EditProfile_Table, null, values);
    }

    public long signUpData(String name, String phoneNumber, String password){
        ContentValues values = new ContentValues();
        values.put(COLUMN_SignUpName, name);
        values.put(COLUMN_SignUpPhone, phoneNumber);
        values.put(Column_passwordInput, password);
        return db.insert(SignUp_Table, null, values);
    }
    public long signUpEmployerData(String name, String phoneNumber, String password){
        ContentValues values = new ContentValues();
        values.put(COLUMN_SignUpEmployerName, name);
        values.put(COLUMN_SignUpEmployerPhone, phoneNumber);
        values.put(Column_passwordEmployerInput, password);
        return db.insert(SignUpEmployer_Table, null, values);
    }

    public long insertData(String name, String date, String residential,
                           String resumePath, String educationLevel, String interestArea) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_RESIDENTIAL, residential);
        values.put(COLUMN_RESUME_PATH, resumePath);
        values.put(COLUMN_EDUCATION_LEVEL, educationLevel); // Add this line
        values.put(COLUMN_INTEREST_AREA, interestArea); // Add this line

        return db.insert(TABLE_NAME, null, values);
    }

    public long anotherinsertData(String name, String business, String nature,
                           String contact, String registering, String date,String position,String fileName) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_CompanyNAME, name);
        values.put(Company_DATE, date);
        values.put(COLUMN_Business, business);
        values.put(Column_Nature, nature);
        values.put(Company_Contact, contact); // Add this line
        values.put(Registering_Person, registering); // Add this line
        values.put(Position, position); // Add this line
        values.put(Company_file, fileName); // Add this line

        return db.insert(ANOTHER_TABLE_NAME, null, values);
    }
    public boolean Loginfetch(String username, String phone, String password) {
        // Assuming you have a table for user credentials with columns "USERNAME", "PHONE", and "PASSWORD"
        String loginQuery = "SELECT * FROM " + SignUp_Table +
                " WHERE " + COLUMN_SignUpName + " = ? AND " + COLUMN_SignUpPhone + " = ? AND " + Column_passwordInput + " = ?";

        String[] selectionArgs = {username, phone, password}; // Include the phone in selectionArgs

        Cursor cursor = db.rawQuery(loginQuery, selectionArgs);

        try {
            // Check if the cursor has any rows, indicating a successful login
            return cursor.moveToFirst();
        } finally {
            cursor.close();
        }
    }
    public boolean LoginEmployerfetch(String username, String phone, String password) {
        // Assuming you have a table for user credentials with columns "USERNAME", "PHONE", and "PASSWORD"
        String loginQuery = "SELECT * FROM " + SignUpEmployer_Table +
                " WHERE " + COLUMN_SignUpEmployerName + " = ? AND " + COLUMN_SignUpEmployerPhone + " = ? AND " + Column_passwordEmployerInput + " = ?";

        String[] selectionArgs = {username, phone, password}; // Include the phone in selectionArgs

        Cursor cursor = db.rawQuery(loginQuery, selectionArgs);

        try {
            // Check if the cursor has any rows, indicating a successful login
            return cursor.moveToFirst();
        } finally {
            cursor.close();
        }
    }
    private static final String SignUpEmployers_TABLE = "CREATE TABLE IF NOT EXISTS " + EditProfile_Table + " ("
            + COLUMN_EditID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_EditAge + " TEXT,"
            + COLUMN_EditGender + " TEXT,"
            + Column_EditAddress + " TEXT,"
            + Column_EditFile + " TEXT,"
            + Column_pastExperience + " TEXT"
            + ")";

    private static class DatabaseHelper extends SQLiteOpenHelper {
        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(CreateSignUpEmployers_TABLE);
            db.execSQL(CreateJobPostings_TABLE);
            db.execSQL(SignUpEmployers_TABLE);
            db.execSQL(CREATE_Edit_Table);
            db.execSQL(CREATE_SignUp_Table);
            db.execSQL(CREATE_TABLE_QUERY);
            db.execSQL(CREATE_ANOTHER_TABLE_QUERY); // Add this line to create AnotherTable
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // Handle upgrades if needed
        }
    }
}
