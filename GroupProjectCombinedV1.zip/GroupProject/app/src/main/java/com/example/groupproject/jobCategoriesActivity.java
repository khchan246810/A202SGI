package com.example.groupproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class jobCategoriesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.job_categories);
        Button back=findViewById(R.id.backButton);
        Button jobPage=findViewById(R.id.jobIconButton);
        Button salesVacancy=findViewById(R.id.salesAssociateButton);
        Button waiterVacancy=findViewById(R.id.waiterButton);
        Button baristaVacancy=findViewById(R.id.baristaButton);
        Button electricianVacancy=findViewById(R.id.electricianButton);
        Button chefVacancy=findViewById(R.id.chefButton);
        Button courierVacancy=findViewById(R.id.courierButton);
        Button profile_icon= findViewById(R.id.profileIconButton);
        profile_icon.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent=new Intent(jobCategoriesActivity.this,profile_page.class);
                startActivity(intent);
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(jobCategoriesActivity.this,homeActivity.class);
                startActivity(intent);
            }
        });
        salesVacancy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(jobCategoriesActivity.this,vacancyPosition1.class);
                startActivity(intent);
            }
        });
        waiterVacancy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(jobCategoriesActivity.this,vacancyPosition1.class);
                startActivity(intent);
            }
        });
        baristaVacancy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(jobCategoriesActivity.this,vacancyPosition1.class);
                startActivity(intent);
            }
        });
        electricianVacancy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(jobCategoriesActivity.this,vacancyPosition1.class);
                startActivity(intent);
            }
        });
        chefVacancy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(jobCategoriesActivity.this,vacancyPosition1.class);
                startActivity(intent);
            }
        });
        courierVacancy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(jobCategoriesActivity.this,vacancyPosition1.class);
                startActivity(intent);
            }
        });
        jobPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(jobCategoriesActivity.this,myJobActivity.class);
                startActivity(intent);
            }
        });
    }
}
