package com.example.groupproject;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;

public class employerProfileSetup extends AppCompatActivity {
    private TextView DateText;
    private ImageButton date;
    private EditText Name, residential;
    private Button confirm;
    private static final int FILE_SELECT_CODE = 1;
    private TextView fileNameText;
    boolean isAllFieldsChecked = false;
    private DatabaseManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employer_profile_setup);

        dbManager = new DatabaseManager(this);
        dbManager.open();

        Spinner educationLevel = findViewById(R.id.educationLevel);
        String[] educationLevelWithDefault = {"Choose the Education Level", "Primary Level", "Secondary Level", "Tertiary Level", "PHD Level", "Master Level", "Professor Level", "Doctor Level"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, educationLevelWithDefault);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        educationLevel.setAdapter(adapter);

        Spinner interestArea = findViewById(R.id.areaOfInterest);
        String[] interestAreaWithDefault = {"Choose the Area of Interest", "Sales associate", "Waiter", "Rider", "Cashier"};
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, interestAreaWithDefault);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        interestArea.setAdapter(adapter);

        Name = findViewById(R.id.Name);
        residential = findViewById(R.id.residential);
        fileNameText = findViewById(R.id.file_name_text);
        DateText = findViewById(R.id.birth);
        date = findViewById(R.id.calendar);

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDatePicker();
            }
        });

        Button selectFileButton = findViewById(R.id.upload);
        selectFileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();
            }
        });
        ImageButton goback = findViewById(R.id.simpleImageButtonHome);
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(employerProfileSetup.this, loginEmployer.class);
                startActivity(intent);
            }
        });

        Button confirmation = findViewById(R.id.confirm);
        confirmation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isAllFieldsChecked = CheckAllFields();
                if (isAllFieldsChecked) {
                    saveDataToDatabase();
                    Intent intent = new Intent(employerProfileSetup.this, employerCompanyProfileSetup.class);
                    startActivity(intent);
                }
            }

        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_SELECT_CODE && resultCode == RESULT_OK) {
            Uri uri = data.getData();
            String fileName = getFileName(uri);
            fileNameText.setText(fileName);
        }
    }

    private void showFileChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(intent, "Select File"), FILE_SELECT_CODE);
    }

    private String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    result = cursor.getString(nameIndex);
                }
            }
        }
        if (result == null) {
            result = uri.getPath();
            int cut = result.lastIndexOf('/');
            if (cut != -1) {
                result = result.substring(cut + 1);
            }
        }
        return result;
    }

    private void openDatePicker() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                DateText.setText(String.valueOf(year) + "." + String.valueOf(month) + "." + String.valueOf(day));
            }
        }, year, month, day);

        datePickerDialog.show();
    }

    private boolean CheckAllFields() {
        if (TextUtils.isEmpty(Name.getText().toString())) {
            Toast.makeText(employerProfileSetup.this, "Fill up the fields. For file, date and dropdown, please select it.", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            Name.setError(null);
        }

        if (TextUtils.isEmpty(residential.getText().toString())) {
            Toast.makeText(employerProfileSetup.this, "Fill up the fields. For file, date and dropdown, please select it.", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            residential.setError(null);
        }

        if (TextUtils.isEmpty(DateText.getText().toString())) {
            Toast.makeText(employerProfileSetup.this, "Fill up the fields. For file, date and dropdown, please select it.", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            DateText.setError(null);
        }

        if (TextUtils.isEmpty(fileNameText.getText().toString())) {
            Toast.makeText(employerProfileSetup.this, "Fill up the fields. For file, date and dropdown, please select it.", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            fileNameText.setError(null);
        }

        Spinner educationLevel = findViewById(R.id.educationLevel);
        if (educationLevel.getSelectedItem().toString().equals("Choose the Education Level")) {
            Toast.makeText(employerProfileSetup.this, "Fill up the fields. For file, date and dropdown, please select it.", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            ((TextView) educationLevel.getSelectedView()).setError(null);
        }

        Spinner interestArea = findViewById(R.id.areaOfInterest);
        if (interestArea.getSelectedItem().toString().equals("Choose the Area of Interest")) {
            Toast.makeText(employerProfileSetup.this, "Fill up the fields. For file, date and dropdown, please select it.", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            ((TextView) interestArea.getSelectedView()).setError(null);
        }

        return true;
    }

    private void saveDataToDatabase() {
        String name = Name.getText().toString();
        String date = DateText.getText().toString();
        String residential = this.residential.getText().toString();
        String fileName = fileNameText.getText().toString();

        // Get selected values from spinners
        Spinner educationLevelSpinner = findViewById(R.id.educationLevel);
        String educationLevel = educationLevelSpinner.getSelectedItem().toString();

        Spinner interestAreaSpinner = findViewById(R.id.areaOfInterest);
        String interestArea = interestAreaSpinner.getSelectedItem().toString();

        // Insert data into the database
        long result = dbManager.insertData(name, date, residential, fileName, educationLevel, interestArea);

        if (result != -1) {
            // Data inserted successfully
            showToast("Data inserted successfully");
        } else {
            // Failed to insert data
            showToast("Failed to insert data");
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbManager.close();
    }
}
