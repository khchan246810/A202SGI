package com.example.groupproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageButton;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class loginEmployerPage extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_employer_page);
        AppCompatImageButton backToEmployee= (AppCompatImageButton) findViewById(R.id.backToEmployeeButton);
        Button login=findViewById(R.id.loginButton);
        Button signUp=findViewById(R.id.signUpButton);
        backToEmployee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(loginEmployerPage.this,MainActivity.class);
                startActivity(intent);
            }
        });

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(loginEmployerPage.this,sign.class);
                startActivity(intent);
            }
        });
    }
}
